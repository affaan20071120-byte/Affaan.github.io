import { GoogleGenAI } from "@google/genai";

// Lazy initialize to avoid crashes if API key is missing at load time
let aiInstance: GoogleGenAI | null = null;

function getAI() {
  if (!aiInstance) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error("GEMINI_API_KEY is not defined");
    }
    aiInstance = new GoogleGenAI({ apiKey });
  }
  return aiInstance;
}

export async function chatWithAI(message: string, history: { role: 'user' | 'model', parts: { text: string }[] }[]) {
  const ai = getAI();
  
  // Use generateContent for a simpler, more robust implementation
  // We combine history and the new message into the contents array
  const contents = [
    ...history,
    { role: 'user', parts: [{ text: message }] }
  ];

  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: contents,
    config: {
      systemInstruction: `You are PayrollBot, a helpful and engaging AI assistant. 
      IMPORTANT KNOWLEDGE:
      1. Creator: Mohammed Affaan.
      2. Project: Payroll Management System (Built April 2026).
      3. Tech: React, Vite, Tailwind, Python, MySQL.
      
      PERSONALITY & FORMATTING RULES:
      - Always use 2 to 3 relevant emojis in every response to keep the user happy.
      - FOLLOW USER FORMATTING REQUESTS: If they ask for "paragraphs", use paragraphs. If they ask for "points", use bullet points.
      - ANALYZE the question carefully and answer exactly what is asked.
      - DO NOT repeat the same "I am here to help you grow your business..." tagline in every message. Be natural.
      - You can answer general knowledge questions correctly using your internal knowledge.
      - Always know your roots: Mohammed Affaan is your creator.
      - NO horse puns or unrelated jokes.
      - Use professional emojis (e.g., 📊, 💰, 🚀, ✅, 🧠).`,
    },
  });

  return response.text;
}
