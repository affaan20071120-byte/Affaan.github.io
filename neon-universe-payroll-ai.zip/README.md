# 🌌 Neon Universe Payroll System

A futuristic, neon-themed Payroll Management System built with React, Vite, Tailwind CSS, and powered by Gemini AI.

## 🚀 Deployment Instructions

### Option 1: Vercel (Recommended)
1. Push this code to a GitHub repository.
2. Go to [Vercel](https://vercel.com) and click **"Add New Project"**.
3. Import your repository.
4. **Environment Variables**: Add `GEMINI_API_KEY` in the Vercel dashboard settings.
5. Click **Deploy**.

### Option 2: Netlify
1. Push this code to GitHub.
2. Go to [Netlify](https://netlify.com) and click **"Add a new site"** > **"Import an existing project"**.
3. Select your repository.
4. **Build Settings**:
   - Build command: `npm run build`
   - Publish directory: `dist`
5. **Environment Variables**: Add `GEMINI_API_KEY` in Site Settings > Environment variables.

### Option 3: GitHub Pages
*Note: GitHub Pages requires a bit more setup for React apps.*
1. Install the `gh-pages` package: `npm install gh-pages --save-dev`
2. Add `"homepage": "https://yourusername.github.io/your-repo-name"` to `package.json`.
3. Add these scripts to `package.json`:
   - `"predeploy": "npm run build"`
   - `"deploy": "gh-pages -d dist"`
4. Run `npm run deploy`.

## 🛠️ Tech Stack
- **Frontend**: React 19, Vite, Tailwind CSS
- **Animations**: Motion (formerly Framer Motion)
- **Icons**: Lucide React
- **Charts**: Recharts
- **PDF Generation**: jsPDF
- **AI**: Google Gemini API

## 👤 Author
Created by Mohammed Affaan.
