import { cn } from '../lib/utils';
import { motion, HTMLMotionProps } from 'motion/react';
import React from 'react';

interface GlowButtonProps extends Omit<HTMLMotionProps<"button">, "color"> {
  color: string;
  glowColor?: string;
  enableZoom?: boolean;
  pulse?: boolean;
}

export const GlowButton = React.forwardRef<HTMLButtonElement, GlowButtonProps>(
  ({ className, color, glowColor, enableZoom = true, pulse = false, children, ...props }, ref) => {
    const activeColor = glowColor || color;
    
    return (
      <motion.button
        ref={ref}
        animate={{
          boxShadow: pulse ? [
              `0 0 15px ${activeColor}`,
              `0 0 30px ${activeColor}`,
              `0 0 15px ${activeColor}`
          ] : `0 0 15px ${activeColor}`,
        }}
        transition={pulse ? {
          duration: 2,
          repeat: Infinity,
          ease: "easeInOut"
        } : {}}
        whileHover={{ 
            scale: enableZoom ? 1.05 : 1, 
            boxShadow: `0 0 40px ${activeColor}`, 
            backgroundColor: `${color}15`,
            transition: { duration: 0.2 } 
        }}
        whileTap={{ scale: 0.95 }}
        className={cn(
          "relative overflow-hidden font-bold transition-all duration-300 rounded-full",
          "border-[3px] bg-transparent backdrop-blur-sm",
          className
        )}
        style={{
          borderColor: color,
          color: color,
        }}
        {...props}
      >
        <span className="relative z-10">{children}</span>
      </motion.button>
    );
  }
);
GlowButton.displayName = 'GlowButton';
