import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { GoogleGenAI } from '@google/genai';
import Markdown from 'react-markdown';

interface ChatBotProps {
  onClose: () => void;
  employeesContext: any[];
}

interface Message {
  role: 'user' | 'assistant';
  content: string;
}

export function ChatBot({ onClose, employeesContext }: ChatBotProps) {
  const [messages, setMessages] = useState<Message[]>([{
    role: 'assistant',
    content: "👋 Hi! I'm PayrollBot, your friendly AI assistant. I know the formulas and basic rules. Ask me anything!"
  }]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTo({
        top: scrollRef.current.scrollHeight,
        behavior: 'smooth'
      });
    }
  }, [messages, isTyping]);

  const handleSend = async () => {
    if (!input.trim() || isTyping) return;
    
    const userMsg = input.trim();
    setInput('');
    setMessages(prev => [...prev, { role: 'user', content: userMsg }]);
    
    setIsTyping(true);
    
    try {
      if (!process.env.GEMINI_API_KEY) {
        throw new Error("Missing API Key");
      }
      
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      const contextStr = employeesContext.map(e => `${e.name} (${e.job}) - Net: ${e.netSalary}`).join(', ');
      
      const systemInstruction = `You are PayrollBot, an advanced, cheerful AI ChatBot. Use emojis tastefully. 
        Developer: Mohammed Affaan. 
        Context: The user currently has these employees: ${contextStr || 'None'}.
        CRITICAL RULE: If the user asks a general knowledge question (like "what is a horse" or anything not related to payroll), you MUST answer their question fully, accurately, and politely. DO NOT decline to answer. HOWEVER, after you answer their question, playfully steer the conversation back to payroll and ask if they need help managing the payroll system or calculating salaries.
        FORMATTING RULE: When the user asks you to explain 'in points' or 'bullet points', you MUST answer in lists. When asked to be 'brief', you MUST provide a very short, concise response. 
        ALWAYS use markdown for bolding (** text **), bullet points, and headers.`;

      const formattedHistory = [...messages, { role: 'user' as const, content: userMsg }].map(m => ({
        role: m.role === 'assistant' ? 'model' : 'user',
        parts: [{ text: m.content }]
      }));

      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: formattedHistory,
        config: {
          systemInstruction,
        }
      });

      setMessages(prev => [...prev, { role: 'assistant', content: response.text || "Sorry, I couldn't understand that." }]);
    } catch (err: any) {
      setMessages(prev => [...prev, { role: 'assistant', content: `⚠️ Error reaching AI assistant: ${err.message}` }]);
    } finally {
      setIsTyping(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-[#05050f]/80 backdrop-blur-sm" onClick={onClose}></div>
      <motion.div 
        initial={{ opacity: 0, scale: 0.95, y: 10 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 10 }}
        transition={{ type: 'spring', damping: 25, stiffness: 300 }}
        className="relative flex flex-col bg-[#1a1a2e]/95 backdrop-blur-2xl border-2 border-[#fd79a8] rounded-3xl max-w-[700px] w-full h-[80vh] shadow-[0_0_80px_rgba(253,121,168,0.3)]"
      >
        <div className="flex justify-between items-center p-5 border-b border-[#fd79a8]/30 bg-[#fd79a8]/10 rounded-t-3xl shadow-sm">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#fd79a8] to-[#e056fd] flex items-center justify-center text-xl shadow-[0_0_15px_#fd79a8]">
              🤖
            </div>
            <h2 className="text-[#fd79a8] font-bold text-lg tracking-wide drop-shadow-[0_0_8px_rgba(253,121,168,0.8)]">PayrollBot</h2>
          </div>
          <button 
            onClick={onClose}
            className="w-8 h-8 rounded-full flex items-center justify-center text-[#ff3366] hover:bg-[#ff4757]/20 transition-colors font-bold shadow-sm"
          >
            ✕
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-6 space-y-6 scroll-smooth" ref={scrollRef}>
          <AnimatePresence initial={false}>
            {messages.map((m, i) => (
              <motion.div 
                key={i} 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div 
                  className={`max-w-[85%] p-4 text-[14px] leading-relaxed prose prose-invert prose-p:leading-relaxed prose-pre:bg-black/20 ${
                    m.role === 'user' 
                      ? 'bg-gradient-to-br from-[#0080ff] to-[#0056d6] text-white rounded-2xl rounded-br-sm shadow-[0_4px_15px_rgba(0,128,255,0.4)]'
                      : 'bg-gradient-to-br from-[#2a1b32] to-[#1a1a2e] text-[#e2e8f0] border border-[#fd79a8]/40 rounded-2xl rounded-bl-sm shadow-[0_2px_20px_rgba(253,121,168,0.15)]'
                  }`}
                >
                  {m.role === 'user' ? (
                    <div>{m.content}</div>
                  ) : (
                    <div className="markdown-body">
                       <Markdown
                         components={{
                           strong: ({node, ...props}) => <strong className="text-[#fd79a8] drop-shadow-[0_0_8px_rgba(253,121,168,0.6)] font-bold" {...props} />,
                           li: ({node, ...props}) => <li className="text-[#e2e8f0] marker:text-[#fd79a8]" {...props} />
                         }}
                       >{m.content}</Markdown>
                    </div>
                  )}
                </div>
              </motion.div>
            ))}
            {isTyping && (
              <motion.div 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.9 }}
                className="flex justify-start"
              >
                <div className="max-w-[85%] p-4 bg-white/5 text-[#fd79a8] border border-[#fd79a8]/30 rounded-2xl rounded-bl-sm flex items-center gap-2">
                  <div className="flex gap-1">
                    <motion.div animate={{ y: [0, -5, 0] }} transition={{ repeat: Infinity, duration: 0.6, delay: 0 }} className="w-2 h-2 bg-[#fd79a8] rounded-full" />
                    <motion.div animate={{ y: [0, -5, 0] }} transition={{ repeat: Infinity, duration: 0.6, delay: 0.2 }} className="w-2 h-2 bg-[#fd79a8] rounded-full" />
                    <motion.div animate={{ y: [0, -5, 0] }} transition={{ repeat: Infinity, duration: 0.6, delay: 0.4 }} className="w-2 h-2 bg-[#fd79a8] rounded-full" />
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        <div className="p-5 border-t border-white/10 bg-black/20 rounded-b-3xl">
          <div className="relative flex items-end bg-[#16213e] border border-white/10 rounded-2xl shadow-inner focus-within:border-[#fd79a8]/50 focus-within:ring-1 focus-within:ring-[#fd79a8]/50 transition-all overflow-hidden p-1">
            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  handleSend();
                }
              }}
              placeholder="Message PayrollBot..."
              className="flex-1 bg-transparent px-4 py-3 min-h-[44px] max-h-[120px] text-[14px] text-white placeholder-white/40 focus:outline-none resize-none custom-scrollbar"
              rows={1}
            />
            <button 
              onClick={handleSend}
              disabled={!input.trim() || isTyping}
              className="m-1 w-9 h-9 rounded-xl bg-[#fd79a8] text-[#1a1a2e] flex items-center justify-center flex-shrink-0 disabled:bg-white/10 disabled:text-white/30 transition-colors"
            >
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><line x1="22" y1="2" x2="11" y2="13"></line><polygon points="22 2 15 22 11 13 2 9 22 2"></polygon></svg>
            </button>
          </div>
          <div className="text-center mt-2 text-[10px] text-white/30">
            PayrollBot can make mistakes. Verify important calculations.
          </div>
        </div>
      </motion.div>
    </div>
  );
}
