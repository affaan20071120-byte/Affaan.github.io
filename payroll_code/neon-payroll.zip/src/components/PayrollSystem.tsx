import React, { useState } from 'react';
import { UniverseBackground } from './UniverseBackground';
import { GlowButton } from './GlowButton';
import { Employee, PayrollSettings, defaultSettings } from '../types';
import { EmployeeForm } from './EmployeeForm';
import { StatsModal } from './StatsModal';
import { BreakdownModal } from './BreakdownModal';
import { SortModal } from './SortModal';
import { ChatBot } from './ChatBot';
import { SettingsModal } from './SettingsModal';
import { LiveGraphModal } from './LiveGraphModal';
import { DeleteModal } from './DeleteModal';
import { exportToPDF } from '../lib/pdf-export';
import { Menu, Search, Plus, X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export function PayrollSystem() {
  const [tabsData, setTabsData] = useState<Record<number, Employee[]>>({ 1: [] });
  const [settings, setSettings] = useState<PayrollSettings>(defaultSettings);
  const [search, setSearch] = useState('');
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [isTableVisible, setIsTableVisible] = useState(true);
  
  const [selectedEmpIds, setSelectedEmpIds] = useState<Set<number>>(new Set());

  // Modal States
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingEmp, setEditingEmp] = useState<Employee | undefined>();
  const [isStatsOpen, setIsStatsOpen] = useState(false);
  const [isBreakdownOpen, setIsBreakdownOpen] = useState(false);
  const [isSortOpen, setIsSortOpen] = useState(false);
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isGraphOpen, setIsGraphOpen] = useState(false);
  
  const [isDeleteConfirmOpen, setIsDeleteConfirmOpen] = useState(false);
  const [deleteMode, setDeleteMode] = useState<'selected' | 'all'>('selected');

  // Tabs state
  const [tabs, setTabs] = useState([{ id: 1, title: 'Payroll 1' }]);
  const [activeTab, setActiveTab] = useState(1);
  const employees = tabsData[activeTab] || [];

  const handleAddTab = () => {
    const newId = Date.now();
    const count = tabs.length + 1;
    setTabs([...tabs, { id: newId, title: `Payroll ${count}` }]);
    setActiveTab(newId);
  };
  const handleSetEmployees = (newEmployees: Employee[] | ((prev: Employee[]) => Employee[])) => {
    setTabsData(prev => ({
      ...prev,
      [activeTab]: typeof newEmployees === 'function' ? newEmployees(prev[activeTab] || []) : newEmployees
    }));
  };

  const filteredEmployees = employees.filter(e => 
    e.name.toLowerCase().includes(search.toLowerCase()) || 
    e.empNo.toString().includes(search)
  );

  const handleToggleSidebar = () => setIsSidebarOpen(!isSidebarOpen);
  
  const handleToggleTable = () => setIsTableVisible(!isTableVisible);

  const handleAddEmployee = () => {
    setEditingEmp(undefined);
    setIsFormOpen(true);
  };

  const handleEditEmployee = () => {
    if (selectedEmpIds.size !== 1) {
      alert("Please select exactly one employee to edit.");
      return;
    }
    const empId = Array.from(selectedEmpIds)[0];
    const emp = employees.find(e => e.empNo === empId);
    if (emp) {
      setEditingEmp(emp);
      setIsFormOpen(true);
    }
  };

  const handleDeleteClick = () => {
    if (selectedEmpIds.size > 0) {
      setDeleteMode('selected');
      setIsDeleteConfirmOpen(true);
    } else {
      setDeleteMode('all');
      setIsDeleteConfirmOpen(true);
    }
  };

  const handleConfirmDelete = () => {
    if (deleteMode === 'selected') {
      handleSetEmployees(employees.filter(e => !selectedEmpIds.has(e.empNo)));
      setSelectedEmpIds(new Set());
    } else {
      handleSetEmployees([]);
      setSelectedEmpIds(new Set());
    }
    setIsDeleteConfirmOpen(false);
  };

  const handleSaveEmployee = (emp: Employee) => {
    if (editingEmp) {
      handleSetEmployees(employees.map(e => e.empNo === emp.empNo ? emp : e));
    } else {
      if (employees.some(e => e.empNo === emp.empNo)) {
         alert("Employee Number already exists!");
         return;
      }
      handleSetEmployees([...employees, emp]);
    }
    setIsFormOpen(false);
  };

  const handleSort = (col: string, dir: 'asc' | 'desc') => {
    const sorted = [...employees].sort((a, b) => {
      const valA = (a as any)[col];
      const valB = (b as any)[col];
      if (valA < valB) return dir === 'asc' ? -1 : 1;
      if (valA > valB) return dir === 'asc' ? 1 : -1;
      return 0;
    });
    handleSetEmployees(sorted);
  };

  const handleRowClick = (empNo: number, e: React.MouseEvent) => {
    const newSelected = new Set(selectedEmpIds);
    if (e.ctrlKey || e.metaKey) {
      if (newSelected.has(empNo)) newSelected.delete(empNo);
      else newSelected.add(empNo);
    } else {
      newSelected.clear();
      newSelected.add(empNo);
    }
    setSelectedEmpIds(newSelected);
  };

  const handleShowBreakdown = () => {
     if (selectedEmpIds.size !== 1) {
       alert("Please select exactly one employee.");
       return;
     }
     setIsBreakdownOpen(true);
  };

  return (
    <div className="flex flex-col h-screen w-full overflow-hidden text-white font-sans selection:bg-[#0080ff]/40 bg-[#05050f]">
      <UniverseBackground />
      
  <div className="flex items-end h-14 w-full bg-gradient-to-b from-[#0a0a14] to-[#161625] px-2 pt-2 gap-1 select-none relative z-20 shadow-[0_4px_20px_rgba(0,128,255,0.1)]">
        <div className="flex gap-1 overflow-x-auto flex-1 h-full items-end custom-scrollbar">
          <AnimatePresence initial={false}>
            {tabs.map((tab) => {
              const isActive = activeTab === tab.id;
              return (
              <motion.div 
                key={tab.id}
                layout
                initial={{ opacity: 0, scale: 0.8, width: 0 }}
                animate={{ opacity: 1, scale: 1, width: 'auto' }}
                exit={{ opacity: 0, scale: 0.8, width: 0 }}
                transition={{ type: "spring", stiffness: 400, damping: 30 }}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 pl-3 pr-2 h-[42px] min-w-[200px] max-w-[240px] rounded-t-[14px] transition-all cursor-pointer group relative ${
                  isActive 
                    ? 'bg-[#1e1e35] z-10 text-white shadow-[0_-5px_15px_rgba(0,0,0,0.3)]' 
                    : 'bg-[#10101d] hover:bg-[#161625] text-white/60'
                }`}
              >
                <div className="w-[18px] h-[18px] bg-indigo-500 rounded-[4px] shrink-0 flex items-center justify-center text-white">
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="m12 3-1.912 5.813a2 2 0 0 1-1.275 1.275L3 12l5.813 1.912a2 2 0 0 1 1.275 1.275L12 21l1.912-5.813a2 2 0 0 1 1.275-1.275L21 12l-5.813-1.912a2 2 0 0 1-1.275-1.275L12 3Z"/></svg>
                </div>
                <span className="text-sm font-medium truncate flex-1">{tab.title}</span>
                {tab.id !== 1 && (
                  <button 
                    onClick={(e) => {
                      e.stopPropagation();
                      const newTabs = tabs.filter(t => t.id !== tab.id);
                      setTabs(newTabs);
                      if (activeTab === tab.id) setActiveTab(newTabs[newTabs.length - 1].id);
                    }}
                    className="w-[22px] h-[22px] rounded-full flex items-center justify-center hover:bg-white/10 transition-colors"
                  >
                    <X className="w-3.5 h-3.5 opacity-70 group-hover:opacity-100 text-white" strokeWidth={2.5} />
                  </button>
                )}
                {isActive && <div className="absolute inset-x-0 bottom-[-1px] h-[2px] bg-white z-20 shadow-[0_0_10px_2px_rgba(255,255,255,0.8)]"></div>}
              </motion.div>
              );
            })}
          </AnimatePresence>
          <motion.button 
            layout
            onClick={handleAddTab}
            className="w-9 h-9 mb-1.5 ml-1 rounded-full flex items-center justify-center bg-blue-500/30 hover:bg-blue-500/60 text-cyan-200 transition-colors shrink-0 shadow-[0_0_30px_5px_rgba(0,210,255,0.8)] border-2 border-[#00d2ff] hover:border-cyan-300"
          >
            <Plus className="w-4 h-4 opacity-80 hover:opacity-100" strokeWidth={2.5} />
          </motion.button>
        </div>
      </div>

      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar */}
        <AnimatePresence initial={false}>
          {isSidebarOpen && (
              <motion.div 
              initial={{ width: 0, opacity: 0, x: -50 }}
              animate={{ width: 280, opacity: 1, x: 0 }}
              exit={{ width: 0, opacity: 0, x: -50 }}
              transition={{ type: 'spring', bounce: 0, duration: 0.4 }}
              className="flex-shrink-0 flex flex-col bg-gradient-to-b from-[#1a1a2e]/95 to-[#0b0b1a]/95 border-r border-[#00d2ff]/50 backdrop-blur-3xl z-10 shadow-[0_0_40px_rgba(0,210,255,0.2)] overflow-hidden"
            >
              <div className="w-[280px] p-6 h-full overflow-y-auto custom-scrollbar flex flex-col gap-4">
                <div className="bg-gradient-to-r from-[#0080ff]/20 to-[#00d2ff]/20 text-[#00d2ff] font-bold text-lg text-center p-4 rounded-2xl mb-8 border border-[#00d2ff]/40 flex items-center justify-center gap-3 drop-shadow-[0_0_10px_rgba(0,210,255,0.5)] shrink-0">
                  <span className="text-2xl">⚡</span> PAYROLL HUB
                </div>

                <div className="flex flex-col gap-4 pb-8 shrink-0">
                  <GlowButton color="#00d2ff" glowColor="#00d2ff" onClick={handleAddEmployee} pulse={true} className="py-4 text-sm font-bold tracking-wider uppercase shadow-[0_0_18px_rgba(0,210,255,0.5)]">
                    ➕ Add Employee
                  </GlowButton>
                  <GlowButton color="#ff6b35" glowColor="#ff6b35" onClick={handleEditEmployee} className="py-4 text-sm font-bold tracking-wider uppercase shadow-[0_0_18px_rgba(255,107,53,0.5)]">
                     ✏️ Edit Employee
                  </GlowButton>
                  <GlowButton color="#ff003c" glowColor="#ff003c" onClick={handleDeleteClick} className="py-4 text-sm font-bold tracking-wider uppercase shadow-[0_0_18px_rgba(255,0,60,0.5)]">
                     🗑️ Delete
                  </GlowButton>
                  <GlowButton color="#ffa502" glowColor="#ffa502" onClick={handleToggleTable} className="py-4 text-sm font-bold tracking-wider uppercase shadow-[0_0_18px_rgba(255,165,2,0.5)]">
                     👁️ {isTableVisible ? "Hide" : "Show"} Table
                  </GlowButton>
                  <GlowButton color="#9b59b6" glowColor="#9b59b6" onClick={() => exportToPDF(selectedEmpIds.size > 0 ? employees.filter(e => selectedEmpIds.has(e.empNo)) : employees)} className="py-4 text-sm font-bold tracking-wider uppercase shadow-[0_0_18px_rgba(155,89,182,0.5)]">
                     📄 Export PDF
                  </GlowButton>
                  <GlowButton color="#00e5ff" glowColor="#00e5ff" onClick={() => setIsSortOpen(true)} className="py-4 text-sm font-bold tracking-wider uppercase shadow-[0_0_15px_rgba(0,229,255,0.4)]">
                     🔃 Sort Table
                  </GlowButton>
                  <GlowButton color="#f9ca24" glowColor="#f9ca24" onClick={() => setIsStatsOpen(true)} className="py-4 text-sm font-bold tracking-wider uppercase shadow-[0_0_15px_rgba(249,202,36,0.4)]">
                     📈 Salary Stats
                  </GlowButton>
                  <GlowButton color="#2bcbba" glowColor="#2bcbba" onClick={() => setIsGraphOpen(true)} className="py-4 text-sm font-bold tracking-wider uppercase shadow-[0_0_15px_rgba(43,203,186,0.4)]">
                     📈 Live Graph
                  </GlowButton>
                  <GlowButton color="#e056fd" glowColor="#e056fd" onClick={handleShowBreakdown} className="py-4 text-sm font-bold tracking-wider uppercase shadow-[0_0_15px_rgba(224,86,253,0.4)]">
                     🧾 Breakdown
                  </GlowButton>
                  <GlowButton color="#fc5c65" glowColor="#fc5c65" onClick={() => setIsSettingsOpen(true)} className="py-4 text-sm font-bold tracking-wider uppercase shadow-[0_0_15px_rgba(252,92,101,0.4)]">
                     ⚙️ Settings
                  </GlowButton>
                  <GlowButton color="#fd79a8" glowColor="#fd79a8" onClick={() => setIsChatOpen(true)} className="py-4 text-sm font-bold tracking-wider uppercase shadow-[0_0_15px_rgba(253,121,168,0.4)]">
                     🤖 AI ChatBot
                  </GlowButton>
                  <GlowButton color="#ff4757" glowColor="#ff4757" onClick={() => window.location.reload()} className="py-4 mt-auto text-sm font-bold tracking-wider uppercase shadow-[0_0_15px_rgba(255,71,87,0.5)] bg-red-500/10">
                     🚪 Logout
                  </GlowButton>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Main Content */}
        <div className="flex-1 flex flex-col overflow-hidden relative z-0 p-5 gap-5">
          
          {/* Header Actions */}
          <div className="flex items-center gap-4">
            <button 
              onClick={handleToggleSidebar}
              className="w-12 h-12 rounded-full border-2 border-[#0080ff] bg-[#0080ff]/20 text-[#0080ff] flex items-center justify-center hover:bg-[#0080ff]/40 transition-colors flex-shrink-0"
            >
              <Menu className="w-5 h-5" />
            </button>
            
            <div className="relative flex-1 max-w-2xl">
              <div className="absolute inset-y-0 left-4 flex items-center pointer-events-none">
                <Search className="w-4 h-4 text-white/50" />
              </div>
              <input
                type="text"
                value={search}
                onChange={e => setSearch(e.target.value)}
                placeholder="Search by name or employee number..."
                className="w-full bg-[#161625]/80 backdrop-blur-sm border-2 border-[#00d2ff] rounded-full pl-11 pr-5 py-3 text-sm text-white placeholder-white/50 focus:outline-none focus:border-[#00ffff] focus:ring-4 focus:ring-[#00ffff]/30 transition-all shadow-[0_0_40px_10px_rgba(0,210,255,0.6)]"
              />
            </div>
          </div>

          {/* Table Container */}
          {isTableVisible && (
            <div className="flex-1 overflow-auto bg-[#0f0f23]/40 backdrop-blur-xl border border-[#00d2ff]/40 rounded-[20px] custom-scrollbar relative shadow-[0_0_30px_rgba(0,210,255,0.15)] ring-1 ring-white/10">
              <table className="w-full text-left border-collapse text-sm min-w-[max-content]">
                <thead className="sticky top-0 bg-gradient-to-r from-[#00d2ff]/30 to-[#9b59b6]/30 backdrop-blur-md z-20 shadow-lg border-b border-[#00d2ff]/40">
                  <tr>
                    {[
                      settings.empNoLabel, settings.nameLabel, settings.jobLabel, 
                      settings.basicLabel, settings.daLabel, settings.hraLabel, 
                      settings.allowanceLabel, settings.grossLabel, settings.taxLabel, 
                      settings.healthLabel, settings.carLabel, settings.netLabel, 
                      "Actions"
                    ].map((h) => (
                      <th key={h} className="p-4 font-bold text-white/90 whitespace-nowrap drop-shadow-[0_0_5px_rgba(255,255,255,0.5)]">
                        {h}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {filteredEmployees.length === 0 ? (
                    <tr>
                      <td colSpan={13} className="p-10 text-center text-white/60">
                        <div className="flex flex-col items-center gap-2">
                          <div className="text-5xl opacity-80">👥</div>
                          <div className="text-base font-semibold text-white/80">No employees found. Add some to get started!</div>
                        </div>
                      </td>
                    </tr>
                  ) : (
                    filteredEmployees.map((emp) => {
                      const isSelected = selectedEmpIds.has(emp.empNo);
                      return (
                        <tr 
                          key={emp.empNo} 
                          onClick={(e) => handleRowClick(emp.empNo, e)}
                          className={`cursor-pointer transition-all border-b border-[#00d2ff]/20 ${
                            isSelected ? 'bg-[#00d2ff]/30 backdrop-blur-sm outline outline-1 outline-[#00d2ff]' : 'bg-[#1a1a2e]/20 hover:bg-[#00d2ff]/10'
                          }`}
                        >
                          <td className="p-4 font-mono text-cyan-200">{emp.empNo}</td>
                          <td className="p-4 font-semibold text-sm text-white">{emp.name}</td>
                          <td className="p-4 text-white/90">{emp.job}</td>
                          <td className="p-4 font-mono text-white/90">{emp.basicSalary.toLocaleString('en-US', {minimumFractionDigits:2})}</td>
                          <td className="p-4 font-mono text-[#00ff88]">{emp.da.toLocaleString('en-US', {minimumFractionDigits:2})}</td>
                          <td className="p-4 font-mono text-[#00ff88]">{emp.hra.toLocaleString('en-US', {minimumFractionDigits:2})}</td>
                          <td className="p-4 font-mono text-[#00ff88]">{emp.otherAllowance.toLocaleString('en-US', {minimumFractionDigits:2})}</td>
                          <td className="p-4 font-mono font-semibold text-[#ffa502]">{emp.grossSalary.toLocaleString('en-US', {minimumFractionDigits:2})}</td>
                          <td className="p-4 font-mono text-[#ff4757]">{emp.tax.toLocaleString('en-US', {minimumFractionDigits:2})}</td>
                          <td className="p-4 font-mono text-[#ff4757]">{emp.healthInsurance.toLocaleString('en-US', {minimumFractionDigits:2})}</td>
                          <td className="p-4 font-mono text-[#ff4757]">{emp.carInsurance.toLocaleString('en-US', {minimumFractionDigits:2})}</td>
                          <td className="p-4 font-mono text-[#00ffff] font-bold bg-[#00ffff]/10">{emp.netSalary.toLocaleString('en-US', {minimumFractionDigits:2})}</td>
                          <td className="p-4">
                            <div className="flex flex-col gap-2">
                              <span className="font-mono text-[#feca57] text-xs whitespace-nowrap">{emp.createdAt || '-'}</span>
                              <div className="flex items-center gap-2">
                                <button onClick={(e) => { e.stopPropagation(); setEditingEmp(emp); setIsFormOpen(true); }} className="hover:scale-125 active:scale-95 transition-transform" title="Edit">✏️</button>
                                <button onClick={(e) => { e.stopPropagation(); handleSetEmployees(employees.filter(x => x.empNo !== emp.empNo)); }} className="hover:scale-125 active:scale-95 transition-transform" title="Delete">🗑️</button>
                              </div>
                            </div>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      {/* Modals */}
      <AnimatePresence>
        {isDeleteConfirmOpen && (
          <DeleteModal 
            mode={deleteMode}
            count={selectedEmpIds.size}
            onConfirm={handleConfirmDelete}
            onCancel={() => setIsDeleteConfirmOpen(false)}
          />
        )}
        {isFormOpen && (
          <EmployeeForm 
            employee={editingEmp} 
            settings={settings}
            existingEmployees={employees}
            onSave={handleSaveEmployee} 
            onCancel={() => setIsFormOpen(false)} 
          />
        )}
        {isStatsOpen && (
          <StatsModal employees={employees} onClose={() => setIsStatsOpen(false)} />
        )}
        {isBreakdownOpen && (
          <BreakdownModal 
            employee={employees.find(e => e.empNo === Array.from(selectedEmpIds)[0])!} 
            onClose={() => setIsBreakdownOpen(false)} 
          />
        )}
        {isSortOpen && (
          <SortModal onSort={handleSort} onClose={() => setIsSortOpen(false)} />
        )}
        {isGraphOpen && (
          <LiveGraphModal employees={employees} onClose={() => setIsGraphOpen(false)} />
        )}
        {isSettingsOpen && (
          <SettingsModal 
            settings={settings} 
            onSave={(updated) => { setSettings(updated); setIsSettingsOpen(false); }} 
            onClose={() => setIsSettingsOpen(false)} 
          />
        )}
        {isChatOpen && (
          <ChatBot onClose={() => setIsChatOpen(false)} employeesContext={employees} />
        )}
      </AnimatePresence>

    </div>
  );
}
