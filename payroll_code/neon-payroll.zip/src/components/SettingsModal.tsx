import React, { useState } from 'react';
import { motion } from 'motion/react';
import { PayrollSettings } from '../types';

interface SettingsModalProps {
  settings: PayrollSettings;
  onSave: (newSettings: PayrollSettings) => void;
  onClose: () => void;
}

export function SettingsModal({ settings, onSave, onClose }: SettingsModalProps) {
  const [localSettings, setLocalSettings] = useState<PayrollSettings>(settings);

  const handleChange = (key: keyof PayrollSettings, value: string) => {
    const num = parseFloat(value);
    setLocalSettings(prev => ({
      ...prev,
      [key]: isNaN(num) ? 0 : num / 100 // Convert percentage to decimal
    }));
  };

  const handleSave = () => {
    onSave(localSettings);
  };

  const InputField = ({ label, valueKey }: { label: string; valueKey: keyof PayrollSettings }) => {
    const [draftValue, setDraftValue] = useState(Math.round((localSettings[valueKey] as number) * 100).toString());

    const handleBlur = () => {
      const num = parseFloat(draftValue);
      handleChange(valueKey, isNaN(num) ? '0' : num.toString());
    };

    return (
      <div className="flex justify-between items-center bg-white/5 p-2 rounded-lg border border-white/10 group hover:border-[#fc5c65]/50 transition-colors">
        <label className="text-white/80 text-sm group-hover:text-white transition-colors">{label}</label>
        <div className="flex items-center gap-1 shadow-[0_0_10px_rgba(252,92,101,0.2)]">
          <input
            type="number"
            step="1"
            value={draftValue}
            onClick={(e) => e.stopPropagation()}
            onChange={(e) => setDraftValue(e.target.value)}
            onBlur={handleBlur}
            className="w-16 bg-black/40 border border-white/20 rounded px-2 py-1 text-white text-right focus:outline-none focus:border-[#fc5c65] focus:ring-1 focus:ring-[#fc5c65] transition-all"
          />
          <span className="text-white/50">%</span>
        </div>
      </div>
    );
  };

  const LabelInputField = ({ labelKey }: { labelKey: string }) => {
    const [draftValue, setDraftValue] = useState(localSettings[`${labelKey}Label` as keyof PayrollSettings] as string);

    const handleBlur = () => {
        setLocalSettings(prev => ({ ...prev, [`${labelKey}Label`]: draftValue }));
    };

    return (
        <input
            type="text"
            value={draftValue}
            onChange={(e) => setDraftValue(e.target.value)}
            onBlur={handleBlur}
            className="bg-black/40 border border-white/20 rounded px-2 py-1 text-white text-sm focus:outline-none focus:border-[#fc5c65] focus:ring-1 focus:ring-[#fc5c65] shadow-[0_0_5px_rgba(252,92,101,0.2)] transition-all"
            placeholder={labelKey.toUpperCase()}
        />
    );
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4" onClick={onClose}>
      <div className="absolute inset-0 bg-[#05050f]/80 backdrop-blur-sm"></div>
      <motion.div 
        initial={{ opacity: 0, scale: 0.9, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.9, y: 20 }}
        className="relative bg-[#16213e]/95 backdrop-blur-xl border-2 rounded-3xl p-6 max-w-[600px] w-full"
        style={{ borderColor: "#fc5c65", boxShadow: "0 10px 40px #fc5c6530" }}
        onClick={(e) => e.stopPropagation()}
      >
         <h2 className="text-xl font-bold text-center mb-4 text-[#fc5c65]">
           ⚙️ Payroll Settings
         </h2>

        <div className="grid grid-cols-2 gap-x-6 gap-y-4 max-h-[60vh] overflow-y-auto custom-scrollbar p-2">
          <div className="space-y-2">
            <h3 className="text-[#00ffcc] font-semibold mb-2 border-b border-white/10 pb-1">Officer Rates</h3>
            <InputField label="DA Rate" valueKey="daOfficer" />
            <InputField label="HRA Rate" valueKey="hraOfficer" />
            <InputField label="Tax Rate" valueKey="taxOfficer" />
          </div>
          
          <div className="space-y-2">
            <h3 className="text-[#00ffcc] font-semibold mb-2 border-b border-white/10 pb-1">Manager Rates</h3>
            <InputField label="DA Rate" valueKey="daManager" />
            <InputField label="HRA Rate" valueKey="hraManager" />
            <InputField label="Tax Rate" valueKey="taxManager" />
          </div>

          <div className="space-y-2">
            <h3 className="text-[#00ffcc] font-semibold mb-2 border-b border-white/10 pb-1">Teacher Rates</h3>
            <InputField label="DA Rate" valueKey="daTeacher" />
            <InputField label="HRA Rate" valueKey="hraTeacher" />
            <InputField label="Tax Rate" valueKey="taxTeacher" />
          </div>

          <div className="space-y-2">
            <h3 className="text-[#00ffcc] font-semibold mb-2 border-b border-white/10 pb-1">Default (Others)</h3>
            <InputField label="DA Rate" valueKey="daDefault" />
            <InputField label="HRA Rate" valueKey="hraDefault" />
            <InputField label="Tax Rate" valueKey="taxDefault" />
          </div>
          
          <div className="space-y-4 col-span-2">
            <h3 className="text-[#f9ca24] font-semibold mb-2 border-b border-white/10 pb-1">Column Labels</h3>
            <div className="grid grid-cols-3 gap-2">
              {(['empNo', 'name', 'job', 'basic', 'da', 'hra', 'allowance', 'gross', 'tax', 'health', 'car', 'net'] as const).map(key => (
                  <LabelInputField key={key} labelKey={key}/>
              ))}
            </div>
          </div>
          <div className="space-y-2 col-span-2">
            <h3 className="text-[#f9ca24] font-semibold mb-2 border-b border-white/10 pb-1">Global Additions</h3>
            <div className="grid grid-cols-3 gap-4">
              <InputField label="Allowance" valueKey="allowanceRate" />
              <InputField label="Health Ins." valueKey="healthRate" />
              <InputField label="Car Ins." valueKey="carRate" />
            </div>
          </div>
        </div>

        <div className="flex justify-center gap-4 mt-6">
          <button
            onClick={handleSave}
            className="bg-[#fc5c65] hover:bg-[#ff7e85] text-[#1a1a2e] rounded-xl font-bold text-sm px-8 py-2.5 transition-colors"
          >
            Save Changes
          </button>
          <button
            onClick={onClose}
            className="bg-transparent border border-[#fc5c65] text-[#fc5c65] hover:bg-[#fc5c65]/10 rounded-xl font-bold text-sm px-8 py-2.5 transition-colors"
          >
            Cancel
          </button>
        </div>
      </motion.div>
    </div>
  );
}
